# JMetro
A set of stylesheets (and new skins) based on the Metro design style. These controls and stylesheet are to be used in JavaFX application.

## Documentation
Documentation on JMetro can be found in this link: [http://www.pixelduke.com/jmetro](http://www.pixelduke.com/jmetro)